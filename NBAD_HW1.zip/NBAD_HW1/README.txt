NINER GAMING

This assignment is based on games.

Main files are:-
1)index.html - This is the homepage of the application.
2)categories.html - Displays all the categories of the games.
3)items are individual html game pages
4)myitems.html


Items are the games in each category.Hence categories are
1)arcade.html
2)adventure.html
3)sports.html

Each category of games has 2 files related with it.They are
1)Arcade - pacman.html, contra.html
2)Adventure - creed.html, cell.html
3)Sports - fifa.html, nba.html

Then comes myitem.html page
This page consists of list of games. Clicking on "Update" button redirects to that item (paceman, contra, creed etc.) page.

Clickable items are:- 

Header - Games
Side Navigation bar - Home, Categories
Breadcrumbs - All visible breadcrumbs except the present page
Buttons - Swap, Update





